# Journal des versions

## v1.0 – 13/04/2025
- Première version du projet.
- Fonctionnalités principales :
  - Conseils de nutrition
  - Conseils d’exercices
  - Chat en temps réel (Django + Django Channels)

## v1.1 – 18/08/2025
- Ajout d’un système de supervision via Django LOGGING
- Création du fichier `logs/errors.log` pour enregistrer les erreurs
- Mise en place d’un fichier `ANOMALIES.md` pour consigner les anomalies
- Documentation technique enrichie
