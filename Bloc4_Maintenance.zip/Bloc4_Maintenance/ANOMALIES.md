# Journal des anomalies

## Anomalie 1
- **Date** : 18/08/2025  
- **Type** : Erreur 500 – ZeroDivisionError  
- **Description** : Division par zéro dans la vue `test_error`.  
- **Conditions d’apparition** : accès à l’URL `/test-error/`.  
- **Impact** : indisponibilité de la page (Internal Server Error).  
- **Statut** : Corrigé (vue créée volontairement pour test des logs).  

---

## Anomalie 2
- **Date** :  
- **Type** : …  
- **Description** : …  
- **Conditions d’apparition** : …  
- **Impact** : …  
- **Statut** : …
